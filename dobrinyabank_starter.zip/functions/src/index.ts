import { initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { setGlobalOptions } from "firebase-functions/v2";

initializeApp();
setGlobalOptions({ region: "europe-west1", maxInstances: 10 });
const db = getFirestore();

function requireUser(req: any) {
  if (!req.auth) throw new HttpsError("unauthenticated", "Войдите в аккаунт.");
  return req.auth.uid as string;
}
function requireAdmin(req: any) {
  const uid = requireUser(req);
  if (req.auth.token.admin !== true) throw new HttpsError("permission-denied", "Недостаточно прав.");
  return uid;
}

export const createProfile = onCall(async (req) => {
  const uid = requireUser(req);
  const email = req.auth!.token.email ?? "";
  const nickname = String(req.data?.nickname ?? "").trim().slice(0, 24);
  if (!/^[\p{L}\p{N}_]{3,24}$/u.test(nickname))
    throw new HttpsError("invalid-argument", "Никнейм: 3–24 символа, буквы, цифры или _.");
  const userRef = db.doc(`users/${uid}`);
  await db.runTransaction(async (tx) => {
    const existing = await tx.get(userRef);
    if (existing.exists) return;
    const nickRef = db.doc(`nicknames/${nickname.toLowerCase()}`);
    const nick = await tx.get(nickRef);
    if (nick.exists) throw new HttpsError("already-exists", "Этот никнейм занят.");
    tx.create(nickRef, { uid });
    tx.create(userRef, {
      uid, email, nickname, balance: 1000, role: "user",
      status: "active", createdAt: FieldValue.serverTimestamp()
    });
  });
  return { ok: true };
});

export const logLogin = onCall(async (req) => {
  const uid = requireUser(req);
  const device = String(req.data?.device ?? "Android").slice(0, 100);
  await db.collection("loginEvents").add({
    uid, email: req.auth!.token.email ?? "", device,
    platform: String(req.data?.platform ?? "android").slice(0, 30),
    createdAt: FieldValue.serverTimestamp()
  });
  return { ok: true };
});

export const transfer = onCall(async (req) => {
  const uid = requireUser(req);
  const toUid = String(req.data?.toUid ?? "");
  const amount = Number(req.data?.amount);
  const comment = String(req.data?.comment ?? "").slice(0, 120);
  const requestId = String(req.data?.requestId ?? "");
  if (!toUid || toUid === uid || !Number.isSafeInteger(amount) || amount <= 0 || amount > 1000000 || !/^[A-Za-z0-9_-]{12,80}$/.test(requestId))
    throw new HttpsError("invalid-argument", "Проверьте получателя и сумму.");
  const senderRef = db.doc(`users/${uid}`);
  const receiverRef = db.doc(`users/${toUid}`);
  const txRef = db.doc(`transactions/${requestId}`);
  await db.runTransaction(async (t) => {
    const prior = await t.get(txRef);
    if (prior.exists) return;
    const [sender, receiver] = await Promise.all([t.get(senderRef), t.get(receiverRef)]);
    if (!sender.exists || !receiver.exists) throw new HttpsError("not-found", "Пользователь не найден.");
    if (sender.data()!.status !== "active" || receiver.data()!.status !== "active")
      throw new HttpsError("failed-precondition", "Один из аккаунтов заблокирован.");
    const balance = Number(sender.data()!.balance ?? 0);
    if (balance < amount) throw new HttpsError("failed-precondition", "Недостаточно средств.");
    t.update(senderRef, { balance: balance - amount });
    t.update(receiverRef, { balance: Number(receiver.data()!.balance ?? 0) + amount });
    t.create(txRef, {
      fromUid: uid, toUid, amount, comment, type: "transfer",
      createdAt: FieldValue.serverTimestamp()
    });
  });
  return { ok: true };
});

export const adminAdjustBalance = onCall(async (req) => {
  const adminUid = requireAdmin(req);
  const targetUid = String(req.data?.targetUid ?? "");
  const amount = Number(req.data?.amount);
  const reason = String(req.data?.reason ?? "").trim().slice(0, 160);
  if (!targetUid || !Number.isSafeInteger(amount) || amount === 0 || Math.abs(amount) > 1000000 || !reason)
    throw new HttpsError("invalid-argument", "Укажите пользователя, сумму и причину.");
  const ref = db.doc(`users/${targetUid}`);
  await db.runTransaction(async (t) => {
    const snap = await t.get(ref);
    if (!snap.exists) throw new HttpsError("not-found", "Пользователь не найден.");
    const next = Number(snap.data()!.balance ?? 0) + amount;
    if (next < 0) throw new HttpsError("failed-precondition", "Баланс не может быть отрицательным.");
    t.update(ref, { balance: next });
    const audit = db.collection("adminAudit").doc();
    t.create(audit, { adminUid, targetUid, amount, reason, createdAt: FieldValue.serverTimestamp() });
  });
  return { ok: true };
});

export const adminSetStatus = onCall(async (req) => {
  const adminUid = requireAdmin(req);
  const targetUid = String(req.data?.targetUid ?? "");
  const status = req.data?.status;
  if (!targetUid || !["active", "blocked"].includes(status))
    throw new HttpsError("invalid-argument", "Некорректный статус.");
  await db.doc(`users/${targetUid}`).update({ status });
  await db.collection("adminAudit").add({
    adminUid, targetUid, action: "setStatus", status,
    createdAt: FieldValue.serverTimestamp()
  });
  return { ok: true };
});
