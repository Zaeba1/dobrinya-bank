import { initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";

initializeApp();
async function main() {
  const email = process.argv[2];
  if (!email) throw new Error("Usage: npm run set-owner -- owner@example.com");
  const user = await getAuth().getUserByEmail(email);
  await getAuth().setCustomUserClaims(user.uid, { ...(user.customClaims ?? {}), admin: true });
  console.log(`Owner role granted to ${email}.`);
}
main().catch(e => { console.error(e); process.exit(1); });
