package com.dobrinyabank.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import java.util.UUID

private val Green = Color(0xFF078B48)
private val Pale = Color(0xFFF3F8F4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Pale)) { BankApp() } }
    }
}

@Composable
fun BankApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    val functions = remember { FirebaseFunctions.getInstance("europe-west1") }
    var user by remember { mutableStateOf(auth.currentUser) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var nickname by remember { mutableStateOf("") }
    var balance by remember { mutableStateOf<Long?>(null) }
    var page by remember { mutableStateOf("home") }
    var recipient by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun refresh() {
        val uid = auth.currentUser?.uid ?: return
        db.collection("users").document(uid).addSnapshotListener { snap, _ ->
            balance = snap?.getLong("balance")
            nickname = snap?.getString("nickname") ?: nickname
        }
    }
    LaunchedEffect(user?.uid) { if (user != null) refresh() }

    Surface(Modifier.fillMaxSize(), color = Pale) {
        if (user == null) {
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                Text("DOBRINYA BANK", color = Green, fontSize = 29.sp, fontWeight = FontWeight.Black)
                Text("Твой банк. Твои правила.", color = Color.Gray)
                Spacer(Modifier.height(28.dp))
                OutlinedTextField(email, { email = it }, label = { Text("Электронная почта") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(password, { password = it }, label = { Text("Пароль") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(nickname, { nickname = it }, label = { Text("Никнейм (для регистрации)") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(16.dp))
                Button(onClick = {
                    if (busy) return@Button
                    busy = true; message = ""
                    auth.createUserWithEmailAndPassword(email.trim(), password).addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            functions.getHttpsCallable("createProfile").call(hashMapOf("nickname" to nickname.trim()))
                                .addOnSuccessListener {
                                    user = auth.currentUser
                                    functions.getHttpsCallable("logLogin").call(hashMapOf("platform" to "android", "device" to android.os.Build.MODEL))
                                    busy = false
                                }.addOnFailureListener { message = it.message ?: "Ошибка профиля"; busy = false }
                        } else {
                            auth.signInWithEmailAndPassword(email.trim(), password).addOnCompleteListener { login ->
                                if (login.isSuccessful) {
                                    user = auth.currentUser
                                    functions.getHttpsCallable("logLogin").call(hashMapOf("platform" to "android", "device" to android.os.Build.MODEL))
                                } else message = task.exception?.message ?: "Не удалось создать аккаунт"
                                busy = false
                            }
                        }
                    }
                }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text(if (busy) "Подождите…" else "Создать аккаунт") }
                TextButton(onClick = {
                    busy = true
                    auth.signInWithEmailAndPassword(email.trim(), password).addOnCompleteListener {
                        if (it.isSuccessful) {
                            user = auth.currentUser
                            functions.getHttpsCallable("logLogin").call(hashMapOf("platform" to "android", "device" to android.os.Build.MODEL))
                        } else message = it.exception?.message ?: "Ошибка входа"
                        busy = false
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Уже есть аккаунт? Войти") }
                Text(message, color = Color.Red)
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("ДОБРЫНЯ", color = Green, fontWeight = FontWeight.Black, fontSize = 21.sp)
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { auth.signOut(); user = null; balance = null }) { Icon(Icons.Default.ExitToApp, "Выйти") }
                }
                when (page) {
                    "home" -> Column(Modifier.padding(20.dp)) {
                        Text("Привет, ${nickname.ifBlank { "друг" }}!", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(16.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(24.dp)) {
                                Text("ДОСТУПНЫЙ БАЛАНС", color = Color.White.copy(alpha=.8f))
                                Text("${balance?.toString() ?: "…"} монет", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                                Text("Виртуальная валюта DOBRINYA BANK", color = Color.White.copy(alpha=.8f))
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        Button(onClick = { page = "transfer" }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Send, null); Spacer(Modifier.width(8.dp)); Text("Перевести") }
                        OutlinedButton(onClick = { page = "history" }, modifier = Modifier.fillMaxWidth()) { Text("История операций") }
                        OutlinedButton(onClick = { page = "terminal" }, modifier = Modifier.fillMaxWidth()) { Text("Терминал") }
                        Text("ID: ${user!!.uid}", fontSize = 11.sp, color = Color.Gray)
                    }
                    "transfer" -> Column(Modifier.padding(20.dp)) {
                        Text("Перевод", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(recipient, { recipient = it }, label = { Text("UID получателя") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(amount, { amount = it }, label = { Text("Сумма монет") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(note, { note = it }, label = { Text("Комментарий") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            val value = amount.toLongOrNull()
                            if (value == null || value <= 0) { message = "Введите корректную сумму"; return@Button }
                            busy = true
                            val data = hashMapOf<String, Any>("toUid" to recipient.trim(), "amount" to value, "comment" to note, "requestId" to UUID.randomUUID().toString())
                            functions.getHttpsCallable("transfer").call(data).addOnSuccessListener {
                                message = "Перевод выполнен"; recipient = ""; amount = ""; note = ""; busy = false; page = "home"
                            }.addOnFailureListener { message = it.message ?: "Ошибка перевода"; busy = false }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Подтвердить перевод") }
                        TextButton(onClick = { page = "home" }) { Text("Назад") }
                        Text(message, color = Color.Red)
                    }
                    "history" -> Column(Modifier.padding(20.dp)) {
                        Text("История операций", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("История будет подключена к серверным записям в следующем этапе.", color = Color.Gray)
                        TextButton(onClick = { page = "home" }) { Text("Назад") }
                    }
                    else -> Column(Modifier.padding(20.dp)) {
                        Text("Терминал", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Выберите получателя и выполните перевод через защищённую операцию.")
                        Button(onClick = { page = "transfer" }) { Text("Начать перевод") }
                        TextButton(onClick = { page = "home" }) { Text("Назад") }
                    }
                }
            }
        }
    }
}
