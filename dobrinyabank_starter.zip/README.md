# DOBRINYA BANK — starter project

A private virtual-coin system for friends. This is not a real bank and does not process real money.

## Project layout
- `android/` — native Kotlin + Jetpack Compose Android app
- `functions/` — Firebase Cloud Functions (server-authoritative transfers and admin actions)
- `admin/` — separate web admin panel
- `firestore.rules` — deny-by-default database rules
- `firebase.json` — Firebase deployment configuration

## Required setup
1. Create a Firebase project.
2. Enable Email/Password in Authentication.
3. Create a Firestore database.
4. Install Firebase CLI and run `firebase login`.
5. Copy your Firebase Android config to `android/app/google-services.json`.
6. Set Firebase project ID in `.firebaserc` (replace `YOUR_FIREBASE_PROJECT_ID`).
7. In `admin/index.html`, replace the Firebase web config placeholders.
8. Deploy backend:
   ```bash
   cd functions
   npm install
   npm run build
   cd ..
   firebase deploy --only functions,firestore:rules,hosting
   ```
9. Build Android APK from Android Studio after syncing Gradle.

## Create the first owner
Do not put an admin password or service-account key in the Android app or website.
Use a trusted local machine with Firebase Admin SDK credentials:
```bash
cd functions
npm install
export GOOGLE_APPLICATION_CREDENTIALS="/secure/path/service-account.json"
npm run set-owner -- owner@example.com
```
This grants the custom claim `admin: true` to the specified existing Firebase account. Keep the service-account file private and never upload it to GitHub.

## Important notes
- Passwords are never copied into Firestore or shown in the admin panel. Firebase Authentication manages them.
- Login events are recorded by the app after successful sign-in. They include timestamp and platform/device model, not passwords.
- The one-account-per-device rule is best-effort, not absolute. Android identifiers can reset and device attestation needs extra configuration. Do not use IMEI.
- Admin permissions are enforced by Firebase custom claims and Cloud Functions, not by hiding the admin URL.
- The initial balance is assigned server-side once, on account creation.
- This starter needs your Firebase project configuration before it can run.
