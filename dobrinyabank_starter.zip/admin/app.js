import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";
import { getFirestore, collection, getDocs, query, orderBy, limit } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js";
import { getFunctions, httpsCallable } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-functions.js";

// Replace with your Firebase project's WEB app configuration.
const firebaseConfig = { apiKey:"YOUR_API_KEY", authDomain:"YOUR_PROJECT.firebaseapp.com", projectId:"YOUR_PROJECT_ID", appId:"YOUR_APP_ID" };
const app=initializeApp(firebaseConfig), auth=getAuth(app), db=getFirestore(app), functions=getFunctions(app,"europe-west1");
const $=id=>document.getElementById(id);
$("signIn").onclick=async()=>{ $("loginError").textContent=""; try{await signInWithEmailAndPassword(auth,$("email").value,$("password").value)}catch(e){$("loginError").textContent="Не удалось войти. Проверьте данные."} };
$("logout").onclick=()=>signOut(auth);
let allUsers=[];
onAuthStateChanged(auth,async user=>{
 if(!user){$("login").classList.remove("hidden");$("app").classList.add("hidden");$("logout").classList.add("hidden");return}
 const token=await user.getIdTokenResult(true);
 if(token.claims.admin!==true){await signOut(auth);$("loginError").textContent="У этой учётной записи нет прав владельца.";return}
 $("login").classList.add("hidden");$("app").classList.remove("hidden");$("logout").classList.remove("hidden");
 await load();
});
async function load(){
 const snap=await getDocs(collection(db,"users"));allUsers=snap.docs.map(d=>({id:d.id,...d.data()}));$("count").textContent=allUsers.length;renderUsers();
 const q=query(collection(db,"loginEvents"),orderBy("createdAt","desc"),limit(30));
 const logs=await getDocs(q);$("logins").textContent=logs.size;
 $("events").innerHTML=logs.docs.map(d=>{const x=d.data();return `<tr><td>${esc(x.email||"")}</td><td>${esc(x.device||"")}</td><td>${esc(x.platform||"")}</td><td>${fmt(x.createdAt)}</td></tr>`}).join("");
}
function renderUsers(){const s=$("search").value.toLowerCase();$("users").innerHTML=allUsers.filter(u=>(u.email||"").toLowerCase().includes(s)||(u.nickname||"").toLowerCase().includes(s)||(u.id||"").toLowerCase().includes(s)).map(u=>`<tr><td>${esc(u.nickname||"")}<br><small>${esc(u.email||"")}</small></td><td>${Number(u.balance||0).toLocaleString("ru-RU")}</td><td>${esc(u.status||"")}</td><td>${esc(u.id)}</td><td><button data-uid="${esc(u.id)}" data-status="${u.status==="blocked"?"active":"blocked"}">${u.status==="blocked"?"Разблокировать":"Заблокировать"}</button></td></tr>`).join("")}
$("search").oninput=renderUsers;
$("users").onclick=async e=>{const b=e.target.closest("button[data-uid]");if(!b)return;try{await httpsCallable(functions,"adminSetStatus")({targetUid:b.dataset.uid,status:b.dataset.status});await load()}catch(err){alert("Не удалось изменить статус: "+err.message)}};
$("adjust").onclick=async()=>{try{await httpsCallable(functions,"adminAdjustBalance")({targetUid:$("target").value.trim(),amount:Number($("amount").value),reason:$("reason").value.trim()});$("result").textContent="Операция выполнена";await load()}catch(e){$("result").textContent="Ошибка: "+e.message}};
function esc(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function fmt(t){return t?.toDate?t.toDate().toLocaleString("ru-RU"):"—"}
